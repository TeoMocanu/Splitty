To add a new language, please follow these steps:

1. Open the other file inside this kit directory
2. Complete the translation this template file: on each line, replace the English after the '=' sign with the desired translation
3. Put the file inside the folder 'client/src/main/resources/languages'.
4. Make sure you rename it to the language code (e.g. 'messages_nl.properties' for Dutch).
5. Additionally, add a flag image to the folder 'client/src/main/resources/flags'
6. Rename the image file with the same name as the language code (e.g. 'flag_nl.png' for Dutch).
7. Delete this kit, so you can successfully add other languages later on.
